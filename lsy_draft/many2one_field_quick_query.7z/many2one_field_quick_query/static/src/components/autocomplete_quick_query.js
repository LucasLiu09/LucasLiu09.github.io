/** @odoo-module **/

import { AutoComplete } from "@web/core/autocomplete/autocomplete";

export class AutoCompleteQuickQuery extends AutoComplete{

}

AutoCompleteQuickQuery.template = 'many2one_field_quick_query.AutoComplete';