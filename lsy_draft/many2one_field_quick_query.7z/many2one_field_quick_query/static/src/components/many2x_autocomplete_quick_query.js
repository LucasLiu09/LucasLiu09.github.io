/** @odoo-module **/

import { Many2XAutocomplete } from "@web/views/fields/relational_utils";
import { AutoCompleteQuickQuery } from "./autocomplete_quick_query";

export class Many2XAutocompleteQuickQuery extends Many2XAutocomplete {

    get sources() {
        console.log('Many2XAutocompleteQuickQuery sources')
        return [this.optionsSource];
    }
    get optionsSource() {
        return {
            placeholder: this.env._t("Loading..."),
            options: this.loadOptionsSource.bind(this),
            optionTemplate: "many2one_field_quick_query.option",
        };
    }

    async loadOptionsSource(request) {
        console.log('Many2XAutocompleteQuickQuery loadOptionsSource');
        if (this.lastProm) {
            this.lastProm.abort(false);
        }
        this.lastProm = this.orm.call(this.props.resModel, "name_search", [], {
            name: request,
            operator: "ilike",
            args: this.props.getDomain(),
            limit: this.props.searchLimit + 1,
            context: this.props.context,
        });
        const records = await this.lastProm;
        const fields = ['name', 'display_name', 'no_of_recruitment', 'contract_type_id'];
        const context = this.props.context;
        const readRecords = await this.orm.read(this.props.resModel, records.map((r) => r[0]), fields, { context });
        console.log('Many2XAutocompleteQuickQuery readRecords', readRecords);
        // const options = records.map((result) => ({
        //     value: result[0],
        //     label: result[1].split("\n")[0],
        // }));
        for (const r of readRecords){
            for (const [key, value] of Object.entries(r)) {
                if (Array.isArray(value)){
                    r[key] = value[1];
                }else if (value === false){
                    r[key] = '';
                }
            }
        }
        const options = readRecords.map((result) => ({
            value: result.id,
            label: result.display_name,
            ...result,
        }))

        if (this.props.quickCreate && request.length) {
            options.push({
                label: sprintf(this.env._t(`Create "%s"`), request),
                classList: "o_m2o_dropdown_option o_m2o_dropdown_option_create",
                action: async (params) => {
                    try {
                        await this.props.quickCreate(request, params);
                    } catch (e) {
                        if (
                            e &&
                            e.name === "RPC_ERROR" &&
                            e.exceptionName === "odoo.exceptions.ValidationError"
                        ) {
                            const context = this.getCreationContext(request);
                            return this.openMany2X({ context });
                        }
                        // Compatibility with legacy code
                        if (
                            e &&
                            e.message &&
                            e.message.name === "RPC_ERROR" &&
                            e.message.exceptionName === "odoo.exceptions.ValidationError"
                        ) {
                            // The event.preventDefault() is necessary because we still use the legacy
                            e.event.preventDefault();
                            const context = this.getCreationContext(request);
                            return this.openMany2X({ context });
                        }
                        throw e;
                    }
                },
            });
        }

        if (!this.props.noSearchMore && this.props.searchLimit < records.length) {
            options.push({
                label: this.env._t("Search More..."),
                action: this.onSearchMore.bind(this, request),
                classList: "o_m2o_dropdown_option o_m2o_dropdown_option_search_more",
            });
        }

        const canCreateEdit =
            "createEdit" in this.activeActions
                ? this.activeActions.createEdit
                : this.activeActions.create;
        if (!request.length && !this.props.value && (this.props.quickCreate || canCreateEdit)) {
            options.push({
                label: this.env._t("Start typing..."),
                classList: "o_m2o_start_typing",
                unselectable: true,
            });
        }

        if (request.length && canCreateEdit) {
            const context = this.getCreationContext(request);
            options.push({
                label: this.env._t("Create and edit..."),
                classList: "o_m2o_dropdown_option o_m2o_dropdown_option_create_edit",
                action: () => this.openMany2X({ context }),
            });
        }

        if (!records.length && !this.activeActions.create) {
            options.push({
                label: this.env._t("No records"),
                classList: "o_m2o_no_result",
                unselectable: true,
            });
        }

        return options;
    }

}

Many2XAutocompleteQuickQuery.template = "many2one_field_quick_query.Many2XAutocomplete";
Many2XAutocompleteQuickQuery.components = { AutoCompleteQuickQuery };
