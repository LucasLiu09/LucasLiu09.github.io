/** @odoo-module **/
import {registry} from "@web/core/registry";
import { Many2OneField } from "@web/views/fields/many2one/many2one_field";
import { Many2XAutocompleteQuickQuery } from "../components/many2x_autocomplete_quick_query";
// import { AutoComplete } from "@web/core/autocomplete/autocomplete";

export class Many2OneFieldQuickQuery extends Many2OneField {


}

Many2OneFieldQuickQuery.components = {
    Many2XAutocompleteQuickQuery,
};
Many2OneFieldQuickQuery.template = "many2one_field_quick_query.Many2OneField";


registry.category("fields").add("many2one_quick_query", Many2OneFieldQuickQuery);
// the two following lines are there to prevent the fallback on legacy widgets
// registry.category("fields").add("list.many2one", Many2OneField);
// registry.category("fields").add("kanban.many2one", Many2OneField);