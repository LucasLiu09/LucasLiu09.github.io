# -*- coding: utf-8 -*-
# from odoo import http


# class Many2oneFieldQuickQuery(http.Controller):
#     @http.route('/many2one_field_quick_query/many2one_field_quick_query', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/many2one_field_quick_query/many2one_field_quick_query/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('many2one_field_quick_query.listing', {
#             'root': '/many2one_field_quick_query/many2one_field_quick_query',
#             'objects': http.request.env['many2one_field_quick_query.many2one_field_quick_query'].search([]),
#         })

#     @http.route('/many2one_field_quick_query/many2one_field_quick_query/objects/<model("many2one_field_quick_query.many2one_field_quick_query"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('many2one_field_quick_query.object', {
#             'object': obj
#         })
