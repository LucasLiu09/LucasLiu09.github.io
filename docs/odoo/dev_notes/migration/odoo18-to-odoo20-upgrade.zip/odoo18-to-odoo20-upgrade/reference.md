# 升级对照

给 `odoo18-to-odoo20-upgrade` 用。行为说明和源码位置见 [迁移指南](odoo18_to_odoo20_dev_migration.md)。

## OWL props 类型

Owl 2 的 `static props` 加上 `static defaultProps`，合成 `props = useProps(...)`。`t` 从 `@odoo/owl` 导入。

| Owl 2 | Owl 3 |
| :--- | :--- |
| `String` | `t.string()` |
| `Number` | `t.number()` |
| `Boolean` | `t.boolean()` |
| `Object` | `t.object()` |
| `Array` | `t.array()` |
| `Function` | `t.function()` |
| `{ type: Boolean, optional: true }` | `t.boolean().optional()` |
| 同类型，且 `defaultProps` 里有值 | `t.boolean().optional(默认值)` |
| 未列出的类型 | `t.any()`，并在升级说明里记下原类型 |

`slots` 不必放进 schema。

## useService 映射

只替换下表里的服务名。import 路径是 20.0 `owl3-migration.py` 里的 `SERVICES_MAPPING`。

| useService 名 | Plugin 类 | 导入 |
| :--- | :--- | :--- |
| `action` | `ActionManagerPlugin` | `@web/webclient/actions/action_plugin` |
| `notification` | `NotificationPlugin` | `@web/core/notifications/notification_plugin` |
| `ui` | `UIPlugin` | `@web/core/ui/ui_plugin` |
| `hotkey` | `HotkeyPlugin` | `@web/core/hotkeys/hotkey_plugin` |
| `overlay` | `OverlayPlugin` | `@web/core/overlay/overlay_plugin` |
| `effect` | `EffectPlugin` | `@web/core/effects/effect_plugin` |
| `bus_service` | `BusPlugin` | `@bus/services/bus_plugin` |
| `bus.parameters` | `BusParametersPlugin` | `@bus/bus_parameters_plugin` |
| `bus.monitoring_service` | `BusMonitoringPlugin` | `@bus/services/bus_monitoring_plugin` |
| `bus.logs_service` | `BusLogsPlugin` | `@bus/debug/bus_logs_plugin` |
| `assetsWatchdog` | `AssetsWatchdogPlugin` | `@bus/services/assets_watchdog_plugin` |
| `currency` | `CurrencyPlugin` | `@web/webclient/currency_plugin` |
| `frequent_emoji` | `FrequentEmojiPlugin` | `@web/core/emoji_picker/frequent_emoji_plugin` |
| `presence` | `PresencePlugin` | `@bus/services/presence_plugin` |
| `sortable` | `SortablePlugin` | `@web/core/util/sortable_plugin` |
| `simple_notification` | `SimpleNotificationPlugin` | `@bus/simple_notification_plugin` |
| `worker_service` | `WorkerPlugin` | `@bus/services/worker_plugin` |
| `multi_tab` | `MultiTabPlugin` | `@bus/multi_tab_plugin` |
| `mobile` | `MobilePlugin` | `@web_mobile/js/mobile_plugin` |
| `color_scheme` | `ColorSchemePlugin` | `@web_enterprise/webclient/color_scheme/color_scheme_plugin` |

`usePlugin` 从 `@odoo/owl` 导入。企业版路径在社区环境不存在时，不要改这几行，写入升级说明。

## ir.access

`ir.model.access.csv` 列：

```csv
id,name,model_id:id,group_id:id,perm_read,perm_write,perm_create,perm_unlink
```

`ir.access.csv` 列：

```csv
id,name,model_id,group_id/id,operation,domain
```

- `model_id` 写模型的 `_name`（`sale.order`），不要写 `model_sale_order` 这种 xml id。用本模块的 `_name` 对照原来的 `model_<技术名>`；对不上就不要猜。
- `operation` 按创建、读、写、删除的顺序拼字母：`c`、`r`、`u`、`d`。四个权限都是 0 的行不要生成，写入升级说明。
- 有 `group_id` 的行是 permission，domain 留空。
- 原来没有组的访问行，`group_id/id` 留空，这是 restriction。

`ir.rule`：`domain_force` 放进 `domain`。`perm_read` 等四个布尔按同样规则拼 `operation`。没有 `groups` 的规则，`group_id` 留空（restriction）。有组时每个组一条 `ir.access`，`group_id` 用原来的组 xml id。

## read_group

18.0 调用：

```python
Model.read_group(domain, ['amount_total:sum'], ['partner_id'], lazy=False)
```

20.0 后端：

```python
for partner, total in Model._read_group(domain, ['partner_id'], ['amount_total:sum']):
    ...
```

`_read_group` 的关联分组值是 recordset。要 dict、`__domain` 或界面格式时用 `formatted_read_group(domain, groupby, aggregates)`。不要保留 `lazy`。

## Binary

Python 里读到的是 `BinaryValue`：字节在 `.content`，另有 `.filename`、`.size`。RPC `read` 的值是 `{'content': <base64>, 'size': ..., 'filename': ...}`。写入仍可传 base64 字符串。除字段名 `raw` 外，不要把 `bytes` 直接写进 Binary 字段。
