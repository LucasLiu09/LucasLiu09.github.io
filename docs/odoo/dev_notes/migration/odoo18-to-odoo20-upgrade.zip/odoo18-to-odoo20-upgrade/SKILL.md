---
name: odoo18-to-odoo20-upgrade
description: >-
  Ports one Odoo 18 addon to Odoo 20 and writes a new module directory.
  Covers OWL 3 (useProps, proxy, signal.ref, this. in templates), ORM public
  methods (read_group, Domain, ir.access, BinaryValue), and view arch
  (kanban card, search filters). Use when the user asks to upgrade, migrate,
  or port an Odoo module from 18 to 20, or says 升级模块、迁移到 Odoo 20, and
  names the module path or addon name.
---

# Odoo 18 模块升级到 Odoo 20

把用户点名的一个 Odoo 18 addon 移植到 20.0，写成新目录。规则以本目录中的迁移指南为准。

## 文档

| 文档 | 用途 |
| :--- | :--- |
| [odoo18_to_odoo20_dev_migration.md](odoo18_to_odoo20_dev_migration.md) | 18.0 与 20.0 的差异和开发迁移规则，改写时以这份为准 |
| [reference.md](reference.md) | OWL props、useService、ir.access、read_group、Binary 的符号对照 |

## 输入

用户必须给出待升级模块的路径或技术名。没给出就停下来问，不要在仓库里猜一个模块。

输出目录由用户指定时用用户的路径。未指定时写到仓库根下的 `odoo20_addons/<技术名>/`。目录名必须等于原来的技术名（Odoo 用目录名当模块名）。目标已存在时停下来问，不要覆盖。

不要修改源模块。

## 不要做的改写

官方 `owl3-migration` 有三处和 20.0 当前树不一致，不要照搬：

- 不要把 `useRef`、`onRendered`、`useComponent` 改成从 `@web/owl2/utils` 导入。该文件只导出 `render`、`onWillRender`、`useLayoutEffect`、`useEnv`、`useSubEnv`。
- 不要把 `t-ref` 改名为 `t-custom-ref`，不要把 `t-model` 改名为 `t-custom-model`。兼容层没有注册这两个指令。
- 不要把 `useState` 留在 `@odoo/owl` 的导入里。20.0 的包不导出 `useState`、`useRef`、`useExternalListener`。

`has_access` 在 20.0 是 `@typing.final`。不要新增对它的覆盖；收紧权限改 `_check_access` 或 `ir.access` 的 domain。

不要改 `__manifest__.py` 的 `depends`，除非能在模块自己的代码里证明旧依赖已经不存在。依赖对不上时写进升级说明，不要换成猜测的模块名。

## 流程

1. 读源模块的 `__manifest__.py`、`models/`、`security/`、`controllers/`、`views/`、`static/src/`。确认它是 addon（有 manifest）。
2. 把整个模块复制到输出目录，保持技术名。
3. 只在副本上改。manifest 的 `version` 若以 `18.0` 开头，改成 `20.0`，后面的序号保留。
4. 按下面两类规则改副本。每处改动都要能指回源文件里的具体调用。
5. 用「核对」里的搜索再扫一遍副本。剩下的命中写进副本根目录的 `UPGRADE_NOTES.md`，不要假装已经改完。
6. 回复里给出新模块路径、已改文件，以及说明里仍需人工看的项。

`UPGRADE_NOTES.md` 第一行写：`文档由 AI 生成`。接着用清单列出未改完的位置（文件、符号、原因）。没有剩余项时写「没有剩余手工项」。

有 20.0 的 `odoo-bin` 时，可以先对副本执行 `upgrade_code --from 18.0`，再按本 skill 修正脚本改错的 OWL 导入和 `t-custom-*`。没有 20.0 源码树时，不要调用 `odoo-bin`，直接按本 skill 改。

## 可机械替换

只在匹配到的符号上替换，不要全库盲换同名标识符。

| 源 | 目标 |
| :--- | :--- |
| `@api.returns(...)` 整行装饰器 | 删除 |
| `name_search` 定义或关键字实参里的 `args` | `domain` |
| `check_access_rights(op)` 且会抛异常 | `check_access(op)` |
| `check_access_rights(op, raise_exception=False)` 或拿返回值当布尔 | `has_access(op)` |
| `check_access_rule(op)` | `check_access(op)` |
| `_filter_access_rules` / `_filter_access_rules_python` | `_filtered_access` |
| `group_operator=` | `aggregator=` |
| `type='json'` / `type="json"`，且在 `@http.route` | `type="jsonrpc"` |
| `from odoo import SUPERUSER_ID` | `from odoo.api import SUPERUSER_ID` |
| `self._cr` / `self._uid` / `self._context` | `self.env.cr` / `self.env.uid` / `self.env.context` |
| 视图和用户、菜单、动作上的 `groups_id` | `group_ids`。自定义模型自己的 `groups_id` 字段不要改 |
| `t-esc` | `t-out` |
| `t-portal` | `t-custom-portal` |
| `t-slot` | `t-call-slot` |
| date 过滤器上的 `start_month`、`end_month`、`start_year`、`end_year` | 删除这些属性 |
| `<search>` 里面 `<group>` 的 `string` 和 `expand` | 删除。form 里的 `<group string>` 保留 |

`_sql_constraints` 改成类属性，属性名是约束名加前缀下划线：

```python
_name_uniq = models.Constraint(
    'UNIQUE(name)',
    "Name must be unique",
)
```

索引元组同样改成 `models.Index('(partner_id, date)')`。解析不了的列表留在说明里。

`security/ir.model.access.csv` 按 [reference.md](reference.md) 写成 `security/ir.access.csv`，并改 manifest 的 data 列表。`ir.rule` 的 XML 按同一页的规则转成 `ir.access` 记录；一条规则挂了多个组时，每个组一行。转完后不要再加载旧的 access CSV 和 rule XML。

`expression.AND([a, b])` 写成 `Domain(a) & Domain(b)`，`expression.OR` 用 `|`，`expression.NOT` 用取反。文件改为 `from odoo.fields import Domain`。`odoo.osv` 的导入删掉。复杂的 `normalize_domain` / `distribute_not` 不要手改语义，记入说明。

`pytz`：`pytz.timezone(...)` 和 `pytz.utc.localize(dt)` 改为 `dt.replace(tzinfo=UTC).astimezone(self.env.tz)`，`UTC` 从 `datetime` 导入。业务自己构造的时区名不要猜，记入说明。

## 需要看上下文的改写

这些改写要读周围代码。拿不准就保持原样并写入 `UPGRADE_NOTES.md`。

### OWL 组件

- `static props` / `static defaultProps` 合成一条 `props = useProps({...})`。类型写法见 [reference.md](reference.md)。从 `@odoo/owl` 引入 `useProps` 和 `t`。
- `useState(x)` 改为 `proxy(x)`。`reactive(x)` 只有一个参数时同样改为 `proxy(x)`。`reactive` 带第二个回调时不要机械替换，记入说明。
- `useRef("name")` 改为字段 `nameRef = signal.ref()`。template 写成 `t-ref="this.nameRef"`。`.el` 改为调用 `this.nameRef()`。
- `useEffect(fn, () => deps)` 改为从 `@web/owl2/utils` 引入的 `useLayoutEffect`，依赖数组保留。没有第二参数、函数体只读 signal / proxy 时，可以用 Owl 3 的 `useEffect(fn)`。
- `t-model` 的表达式必须是 signal（带 `set`）。原来绑在 `useState` 对象属性上的，把该属性拆成 `signal`，template 写 `t-model="this.field"`。
- 组件 template 和 `xml\`...\`` 字面量里，组件的 props、state、方法加 `this.`。不要给 `t-as` 循环变量、`t-set` 名字、字面量加 `this.`。
- `useExternalListener` 改为 `useListener`（`@odoo/owl` 有导出）。调用形态变了就记入说明，不要只改名字。
- [reference.md](reference.md) 映射表里的 `useService("name")` 改为 `usePlugin(PluginClass)`，并加上对应 import。表以外的 `useService` 保留，记入说明。

### 模型

- `read_group(domain, aggregates, groupby, ...)`：第二个位置参数在 20.0 是 `groupby`，第三个才是聚合。调用和覆盖都改成 `_read_group(domain, groupby, aggregates)`。调用方把结果当 dict、使用 `__domain` 或 `lazy` 时，改用 `formatted_read_group`。位置参数含义不清楚时不要改，记入说明。
- `if not self._check_recursion():` 改为 `if self._has_cycle():`。`_check_m2m_recursion(field)` 改为 `_has_cycle(field)`，条件同样取反。
- `toggle_active` 的覆盖：只在归档时做事的，改成 `action_archive`；只在取消归档时做事的，改成 `action_unarchive`。方法里两种方向都有逻辑时不要合成一个方法，记入说明。
- `get_param` / `set_param`：值当字符串用就换成 `get_str` / `set_str`；和布尔、整数、浮点比较时换成 `get_bool`、`get_int`、`get_float` 及对应的 `set_*`。看不出类型时用 `get_str` 并记入说明。
- Binary 字段：把当 base64 字符串再 `b64decode` 的读取改为 `.content`。`ir.attachment` 的 `datas` 改为 `raw`。对普通 Binary 字段直接赋 `bytes` 会在 20.0 抛 `TypeError`，改为 base64 字符串或 `BinaryValue`。
- `res.groups` 上的 `category_id` 改为新建 `res.groups.privilege`（privilege 上保留 `category_id`），组写 `privilege_id`。

### 视图

- 看板里的 `t-name="kanban-box"` 改为 `t-name="card"`。只有一个根 `div` 时，把这个 div 的 class 挪到 `<t t-name="card">` 上，字段作为 card 的直接子节点。有 `kanban-menu`、进度条或多个根节点时记入说明，不要拆散结构。
- `widget="selection_badge"`：字段是 selection 则改为 `badges_selection`，是 many2one 则改为 `badges_many2one`。`selection_badge_with_filter` 同样处理。字段类型在本模块里查不到就记入说明。
- `<i class="fa fa-...">` 和旧 `oi-*` 图标类不要猜 Material Symbols 的名字。记入说明，列出文件和 class。

## 核对

在副本里搜索下面的字符串。命中且不属于注释或说明文件的，要么改掉，要么写入 `UPGRADE_NOTES.md`：

`useState`、`useRef`、`static props`、`static defaultProps`、`@api.returns`、`odoo.osv`、`check_access_rights`、`check_access_rule`、`_filter_access_rules`、`_check_recursion`、`_check_m2m_recursion`、`toggle_active`、`get_param`、`set_param`、`group_operator`、`_sql_constraints`、`kanban-box`、`selection_badge`、`t-esc`、`t-custom-ref`、`t-custom-model`、`ir.model.access.csv`、`type="json"`、`type='json'`、`groups_id`、`start_month`、`pytz`

`read_group(` 的命中要打开确认参数顺序已经是 `(domain, groupby, aggregates)`，或者已经换成 `_read_group` / `formatted_read_group`。

## 回复

先给新模块的路径。然后列已改的行为类别。最后列 `UPGRADE_NOTES.md` 里的剩余项。不要把源模块说成已经升级。
